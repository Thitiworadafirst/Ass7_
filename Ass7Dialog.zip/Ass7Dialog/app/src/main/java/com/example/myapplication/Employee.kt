package com.example.myapplication

data class Employee (val name:String , val gender:String , val email:String , val salary:Int){
}